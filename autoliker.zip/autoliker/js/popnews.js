var a = " <p><b>Recent News: </b>Tools is Fixed now and is Working Fine (Limite set upto 1 per submit).</p><br><button id='rem'><svg width='1em' height='1em' viewBox='0 0 2048 2048'><path fill='currentColor' d='m1115 1024l690 691l-90 90l-691-690l-691 690l-90-90l690-691l-690-691l90-90l691 690l691-690l90 90l-690 691z'/></svg></button>";
document.write(a);
rem.onclick = function(){
    pop.style.display = "none";
}